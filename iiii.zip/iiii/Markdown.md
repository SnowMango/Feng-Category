Markdown Test
=======

Basic
-----

### 1 Special Characters

`4 < 5 to 4 &lt; 5`

`4 & 5 to 4 &amp; 5`

`&copy;`

### 2 Phrase Emphasis 强调
| 效果 |   例子  |  关键词  |  
|-------|-------|-----------|  
| 斜体  | *example*  |  \*example*  |  
| 加粗  | **example** |  \**example **  |  
| 斜体  | _example_  |  \_example_  |  
| 加粗  | __example__  |  \_\_example__  |  

### 3 Links 链接

* \[example](http://url.com/ "Title")
* An \[example]\[id]. Then, anywhere else in the doc, define the link:

   \[id]: http://example.com/  "Title"
   

### 4 Images 图片

* \!\[alt text](/path/img.jpg "Title")

* \!\[alt text]\[id]

  \[id]: /url/to/img.jpg "Title"
  
### 5 Headers  标题
  
  `This is an H1    
  =============`
  
  `This is an H2   
  -------------`
  
  \# This is an H1
  
  \## This is an H2
  
  \### This is an H3
  
  \#### This is an H4
  
  \##### This is an H5
  
  \###### This is an H6
  
### 6 Lists 列表

1. Number  
    1.  Foo  
    2.  Bar

2.  \* \+ \- Charaters  
    \* Abacus  
    \+ answer  
    \- Bubbles
    
### 7 Blockquotes 块引用

\> Email-style angle brackets  
\> are used for blockquotes.  
\> > And, they can be nested.  
\> #### Headers in blockquotes  
\>  
\> * You can quote a list.  
\> * Etc.

### 8 Code  代码

* \`code` spans are delimited by backticks.  
* \```  code  ``` spans are delimited by backticks.

### 9 Preformatted Code  代码区块

indent every line of a code block by at least 4 spaces or 1 tab.

This is a normal paragraph.

    This is a preformatted code block.

### 10 Horizontal 分隔线

1. \---  
---   

2. \***  
***  
3. \- - -
- - -

### 11 Manual Line 换行

End a line with two or more spaces

Roses are red,   
Violets are blue.

Markdown Common
-----

###  Lists Extra

* add ) Charaters
    \1)  Foo  
    \2)  Foo  
    
### Preformatted Code Extra

* \```  code  ``` support Preformatted Code

```  
    hello world
    This is a preformatted code block.
```  

GitHub Flavored Markdown
-----

### Syntax highlighting 语法高亮

\```javascript 语法名
        function fancyAlert(arg) {
            if(arg) {
                $.facebox({div:'#foo'})
            }
        }
\```

### Task Lists  任务列表

* To create a task list, preface list items with a regular space character followed by [ ]. To mark a task as complete, use [x].

\ - [x] Finish my changes
\ - [ ] Push my commits to GitHub
\ - [ ] \(Optional) Open a followup issue

### Tables 表格

| Left-Aligned | Center Aligned | Right Aligned |   
| :------------ |:---------------:| -----:|   
| col 3 is | some wordy text | $1600 |  
| col 2 is | centered | $12 |   
| zebra stripes | are neat | $1 |  

### Automatic linking for URLs

* Automatic
  http://www.github.com/  
  164804868@qq.com

* \ <http://www.github.com/>
  \<164804868@qq.com>

### Strikethrough

`~~This was mistaken text~~`  => ~~This was mistaken text~~

### Emoji

* You can add emoji to your writing by typing :EMOJICODE: [emoji-cheat-sheet](http://emoji-cheat-sheet.com/)

`:blush:` = :blush:
`:joy:` = :joy:
`:grinning:` = :grinning:


